import React from 'react'

const RadioInput = () => {
  return (
    <div>
      
    </div>
  )
}

export default RadioInput
